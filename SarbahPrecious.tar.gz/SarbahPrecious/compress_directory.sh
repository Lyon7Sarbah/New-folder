#!/bin/bash

# Compress the directory
tar -czvf SarbahPrecious.tar.gz SarbahPrecious


